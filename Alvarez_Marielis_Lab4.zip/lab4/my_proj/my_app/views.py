from django.views import View
from django.shortcuts import render, redirect
from my_app.my_functions import title_case_list


class HomePageView(View):
    def get(self, request):
        # Define the list of names with some uppercase characters
        names = ['aLiCe', 'bOb', 'cHarlie']

        # Use the title_case_list function to fix the names
        fixed_names = title_case_list(names)

        # Pass the fixed names in the context
        context = {'hiya!': 'hello world!',
                   'names': fixed_names}

        return render(request, 'my_app/index.html', context)


from django.shortcuts import render
from .models import Car  # Assuming Car is a model in your Django app

def my_view(request):
    car1 = Car(make='Toyota', model='Camry', year=2022, color='Red', honk_sound='Beep')
    car2 = Car(make='Honda', model='Accord', year=2023, color='Blue', honk_sound='Honk')

    context = {
        'car1': car1,
        'car2': car2,
    }

    return render(request, 'template_name.html', context)



        # Creating a dictionary
person = {
    'name': 'John',
    'age': 20
}

# views.py

from django.shortcuts import render
from .my_objects import Car, Truck, Motorcycle

def my_view(request):
    car = Car(make='Toyota', model='Camry', year=2022, color='Red')
    truck = Truck(make='Ford', model='F-150', year=2021, color='Blue')
    motorcycle = Motorcycle(make='Harley-Davidson', model='Sportster', year=2023, color='Black')

    context = {
        'car': car,
        'truck': truck,
        'motorcycle': motorcycle,
    }

    return render(request, 'template_name.html', context)


# Accessing values in a dictionary
print("Name:", person['name'])
print("Age:", person['age'])

# Modifying values in a dictionary
person['age'] = 25
print("Updated Age:", person['age'])

# Adding new key-value pairs
person['city'] = 'New York'
print("City:", person['city'])

# Removing a key-value pair
del person['age']
print("After deleting age:", person)

# Checking if a key exists
if 'name' in person:
    print("'name' exists in person dictionary")

# Length of a dictionary
print("Length of dictionary:", len(person))

# Iterating over a dictionary
for key, value in person.items():
    print(key, ":", value)

