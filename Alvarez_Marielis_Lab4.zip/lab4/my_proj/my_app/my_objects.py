# my_objects.py

class Car:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
        self.odometer_reading = 0

    def get_make(self):
        return self.make

    def get_model(self):
        return self.model

    def get_year(self):
        return self.year

    def read_odometer(self):
        return f"This car has {self.odometer_reading} miles on it."

    def update_odometer(self, mileage):
        if mileage >= self.odometer_reading:
            self.odometer_reading = mileage
        else:
            print("You can't roll back an odometer!")

    def increment_odometer(self, miles):
        self.odometer_reading += miles

class Vehicle:
    def __init__(self, make, model, year, color, wheels):
        self.make = make
        self.model = model
        self.year = year
        self.color = color
        self.wheels = wheels

# my_objects.py

class Car(Vehicle):
    def __init__(self, make, model, year, color):
        super().__init__(make, model, year, color, wheels=4)

class Truck(Vehicle):
    def __init__(self, make, model, year, color):
        super().__init__(make, model, year, color, wheels=6)

class Motorcycle(Vehicle):
    def __init__(self, make, model, year, color):
        super().__init__(make, model, year, color, wheels=2)
