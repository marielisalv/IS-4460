def title_case_list(input_list):
    """Title case each element in the input list."""
    return [item.title() for item in input_list]
